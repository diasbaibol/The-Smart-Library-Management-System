package edu.aitu.library.exception;

public class NotFoundException extends LibraryException {
    public NotFoundException(String message) { super(message); }
}
