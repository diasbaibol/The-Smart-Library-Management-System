package edu.aitu.library.exception;

public class ReservationExistsException extends LibraryException {
    public ReservationExistsException(String message) { super(message); }
}
