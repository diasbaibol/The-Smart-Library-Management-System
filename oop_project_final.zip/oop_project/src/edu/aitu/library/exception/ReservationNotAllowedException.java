package edu.aitu.library.exception;

public class ReservationNotAllowedException extends LibraryException {
    public ReservationNotAllowedException(String message) { super(message); }
}
